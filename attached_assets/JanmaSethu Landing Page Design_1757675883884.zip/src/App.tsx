import { HeroSection } from "./components/HeroSection";
import { AboutSection } from "./components/AboutSection";
import { JourneySection } from "./components/JourneySection";
import { SakhiSection } from "./components/SakhiSection";
import { ClinicsSection } from "./components/ClinicsSection";
import { InvestorsSection } from "./components/InvestorsSection";
import { EvidenceSection } from "./components/EvidenceSection";
import { ClosingCTA } from "./components/ClosingCTA";
import { motion } from "motion/react";
import { Menu, X } from "lucide-react";
import { useState } from "react";

function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: "About", href: "#about" },
    { name: "Journey", href: "#journey" },
    { name: "Sakhi", href: "#sakhi" },
    { name: "Clinics", href: "#clinics" },
    { name: "Investors", href: "#investors" },
    { name: "Evidence", href: "#evidence" }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.div
            className="text-xl font-bold text-primary"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            JanmaSethu
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item, index) => (
              <motion.a
                key={item.name}
                href={item.href}
                className="text-muted-foreground hover:text-primary transition-colors duration-200"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                {item.name}
              </motion.a>
            ))}
            <motion.button
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Get Started
            </motion.button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-muted-foreground hover:text-primary"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <motion.div
          className="md:hidden overflow-hidden"
          initial={{ height: 0 }}
          animate={{ height: isOpen ? "auto" : 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="py-4 space-y-4">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="block text-muted-foreground hover:text-primary transition-colors duration-200"
                onClick={() => setIsOpen(false)}
              >
                {item.name}
              </a>
            ))}
            <button className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity text-left">
              Get Started
            </button>
          </div>
        </motion.div>
      </div>
    </nav>
  );
}

function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16 px-4">
      <div className="container mx-auto max-w-7xl">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold">JanmaSethu</h3>
            <p className="text-gray-400 text-sm">
              Bridge to Parenthood. For every step of the journey.
            </p>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">For Patients</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">Meet Sakhi</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Journey Guide</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Support Community</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">For Clinics</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">Partnership Program</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Outcome Analytics</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Integration Support</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2024 JanmaSethu. All rights reserved. Guidance, not diagnosis.</p>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main>
        <HeroSection />
        
        <section id="about">
          <AboutSection />
        </section>
        
        <section id="journey">
          <JourneySection />
        </section>
        
        <section id="sakhi">
          <SakhiSection />
        </section>
        
        <section id="clinics">
          <ClinicsSection />
        </section>
        
        <section id="investors">
          <InvestorsSection />
        </section>
        
        <section id="evidence">
          <EvidenceSection />
        </section>
        
        <ClosingCTA />
      </main>
      
      <Footer />
    </div>
  );
}