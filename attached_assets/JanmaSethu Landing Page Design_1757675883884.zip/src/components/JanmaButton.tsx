import { cn } from "./ui/utils";
import { motion } from "motion/react";

interface JanmaButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'tertiary';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: () => void;
  href?: string;
}

export function JanmaButton({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  className,
  onClick,
  href
}: JanmaButtonProps) {
  const baseClasses = "inline-flex items-center justify-center rounded-lg transition-all duration-200 cursor-pointer border";
  
  const variantClasses = {
    primary: "bg-primary text-primary-foreground border-primary hover:opacity-90 shadow-md hover:shadow-lg",
    secondary: "bg-transparent text-primary border-primary hover:bg-primary/5",
    tertiary: "bg-transparent text-primary border-transparent hover:bg-primary/5"
  };
  
  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3",
    lg: "px-8 py-4 text-lg"
  };

  const Component = href ? motion.a : motion.button;
  const props = href ? { href } : { onClick };

  return (
    <Component
      className={cn(baseClasses, variantClasses[variant], sizeClasses[size], className)}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      {...props}
    >
      {children}
    </Component>
  );
}