import { motion, useMotionValue, useSpring, useInView } from "motion/react";
import { useEffect, useRef } from "react";
import { TrendingUp, TrendingDown, Target, Building2 } from "lucide-react";

const stats = [
  {
    icon: TrendingUp,
    value: 85,
    suffix: "%",
    label: "Show Rate",
    description: "Patient attendance improvement",
    color: "text-green-500",
    bgColor: "bg-green-500/10"
  },
  {
    icon: TrendingDown,
    value: 40,
    suffix: "%",
    label: "Cancellations",
    description: "Reduction in last-minute cancellations",
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
    isDecrease: true
  },
  {
    icon: Target,
    value: 92,
    suffix: "/100",
    label: "Prep Score",
    description: "Patient preparation quality",
    color: "text-purple-500",
    bgColor: "bg-purple-500/10"
  }
];

function AnimatedCounter({ value, suffix, isDecrease }: { value: number; suffix: string; isDecrease?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const motionValue = useMotionValue(0);
  const springValue = useSpring(motionValue, { duration: 2000 });
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      // After-delay count-up: start at 0, then animate to target
      setTimeout(() => {
        motionValue.set(value);
      }, 500);
    }
  }, [motionValue, value, isInView]);

  useEffect(() => {
    springValue.on("change", (latest) => {
      if (ref.current) {
        const displayValue = Math.round(latest);
        ref.current.textContent = `${isDecrease ? '-' : '+'}${displayValue}${suffix}`;
      }
    });
  }, [springValue, suffix, isDecrease]);

  // Initially show 0
  useEffect(() => {
    if (ref.current && !isInView) {
      ref.current.textContent = `${isDecrease ? '-' : '+'}0${suffix}`;
    }
  }, [suffix, isDecrease, isInView]);

  return <div ref={ref}></div>;
}

export function ClinicsSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-muted/10 to-background">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Building2 className="text-blue-500" size={24} />
            <h2 className="text-3xl md:text-4xl">For Clinics</h2>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Transform patient outcomes with evidence-based preparation and support
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="group relative"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <div className="relative p-8 rounded-2xl bg-card border border-border shadow-lg group-hover:shadow-xl transition-all duration-300 text-center">
                {/* Background gradient */}
                <div className={`absolute inset-0 rounded-2xl ${stat.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
                
                <div className="relative z-10">
                  {/* Icon */}
                  <div className={`inline-flex p-3 rounded-xl ${stat.bgColor} mb-6 ${stat.color}`}>
                    <stat.icon size={32} />
                  </div>
                  
                  {/* Big numerals with count-up */}
                  <motion.div 
                    className={`text-5xl font-bold mb-2 ${stat.color}`}
                    initial={{ scale: 0.5 }}
                    whileInView={{ scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.2 + 0.3 }}
                    viewport={{ once: true }}
                  >
                    <AnimatedCounter 
                      value={stat.value} 
                      suffix={stat.suffix}
                      isDecrease={stat.isDecrease}
                    />
                  </motion.div>
                  
                  <h3 className="text-xl mb-2">{stat.label}</h3>
                  <p className="text-sm text-muted-foreground">
                    {stat.description}
                  </p>
                </div>

                {/* Hover effect border */}
                <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-primary/20 transition-colors duration-300"></div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tagline under stats */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          viewport={{ once: true }}
        >
          <p className="text-xl font-medium text-primary">
            Outcome-based pilot. No retainer.
          </p>
        </motion.div>

        {/* Additional content */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="bg-card border border-border rounded-2xl p-8 max-w-3xl mx-auto">
            <h3 className="text-xl mb-4">Partnership Benefits</h3>
            <div className="grid md:grid-cols-2 gap-6 text-left">
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-muted-foreground">Improved patient preparation and outcomes</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-muted-foreground">Reduced administrative burden</span>
                </li>
              </ul>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-muted-foreground">Enhanced patient satisfaction</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-muted-foreground">Data-driven insights for better care</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}