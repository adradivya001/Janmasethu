import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { MessageCircle, Smartphone } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const chatMessages = [
  {
    type: "user",
    text: "I'm 6 weeks pregnant and feeling anxious about my first prenatal appointment. What should I expect?"
  },
  {
    type: "sakhi",
    text: "Congratulations on your pregnancy! 🎉 Your first prenatal appointment is an exciting milestone. Here's what typically happens:\n\n• Medical history review\n• Physical examination\n• Blood tests for health screening\n• Estimated due date calculation\n• Discussion of prenatal vitamins\n\nWould you like me to help you prepare questions for your doctor?"
  }
];

export function SakhiSection() {
  const [showTyping, setShowTyping] = useState(true);
  const [showMessage, setShowMessage] = useState(false);

  useEffect(() => {
    // Initial typing delay (1s) then fade in answer (0.3s)
    const timer1 = setTimeout(() => {
      setShowTyping(false);
      setShowMessage(true);
    }, 1000);

    // Reset cycle after showing message
    const timer2 = setTimeout(() => {
      setShowTyping(true);
      setShowMessage(false);
    }, 5000);

    // Continuous loop
    const interval = setInterval(() => {
      setShowTyping(true);
      setShowMessage(false);
      
      setTimeout(() => {
        setShowTyping(false);
        setShowMessage(true);
      }, 1000);
    }, 6000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearInterval(interval);
    };
  }, []);

  return (
    <section className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">Meet Sakhi</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Your 24×7 health companion
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Chat Preview */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="bg-card border border-border rounded-2xl p-6 shadow-lg">
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-border">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <MessageCircle className="text-primary-foreground" size={20} />
                </div>
                <div>
                  <h3 className="font-medium">Sakhi</h3>
                  <p className="text-sm text-green-500">● Online</p>
                </div>
              </div>

              <div className="space-y-4 max-h-80 overflow-y-auto">
                {/* User message */}
                <div className="flex justify-end">
                  <div className="bg-primary text-primary-foreground rounded-2xl rounded-br-md px-4 py-3 max-w-xs">
                    <p className="text-sm">{chatMessages[0].text}</p>
                  </div>
                </div>

                {/* Typing indicator */}
                <motion.div
                  className="flex justify-start"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ 
                    opacity: showTyping ? 1 : 0,
                    scale: showTyping ? 1 : 0.8
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3">
                    <div className="flex space-x-1">
                      <motion.div
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: 0 }}
                      />
                      <motion.div
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                      />
                      <motion.div
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                      />
                    </div>
                  </div>
                </motion.div>

                {/* Sakhi response */}
                <motion.div
                  className="flex justify-start"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ 
                    opacity: showMessage ? 1 : 0,
                    y: showMessage ? 0 : 20
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3 max-w-sm">
                    <p className="text-sm whitespace-pre-line">{chatMessages[1].text}</p>
                  </div>
                </motion.div>
              </div>
            </div>
          </motion.div>

          {/* App Mockup */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="relative mx-auto w-full max-w-sm">
              {/* Phone frame */}
              <div className="relative bg-gray-900 rounded-[2.5rem] p-2 shadow-2xl">
                <div className="bg-background rounded-[2rem] overflow-hidden">
                  {/* Status bar */}
                  <div className="bg-background px-6 py-2 flex justify-between items-center text-xs">
                    <span>9:41</span>
                    <div className="flex gap-1">
                      <div className="w-4 h-2 bg-muted rounded-sm"></div>
                      <div className="w-4 h-2 bg-muted rounded-sm"></div>
                      <div className="w-4 h-2 bg-green-500 rounded-sm"></div>
                    </div>
                  </div>
                  
                  {/* App content - maintain 16px gutters */}
                  <div className="p-4">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBtb2NrdXAlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1Njc5MTkzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      alt="JanmaSethu App Interface"
                      className="w-full h-80 object-cover rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/20 rounded-[2.5rem] blur-2xl -z-10"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}