import { motion } from "motion/react";
import { JanmaButton } from "./JanmaButton";

export function HeroSection() {
  return (
    <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted/20 px-4 py-16 md:py-20 lg:py-24">
      <div className="container mx-auto max-w-7xl">
        <div className="grid lg:grid-cols-2 gap-8 md:gap-12 lg:gap-16 items-center">
          {/* Left side - Content */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="space-y-6">
              <motion.h1 
                className="text-[36px] leading-[1.1] md:text-[64px] md:leading-[72px]"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                Bridge to Parenthood.
                <br />
                <span className="text-muted-foreground">For every step of the journey.</span>
              </motion.h1>
              <motion.p 
                className="text-lg text-muted-foreground max-w-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                JanmaSethu connects you with personalized guidance, expert support, and a caring community throughout your parenthood journey.
              </motion.p>
            </div>
            
            <motion.div 
              className="flex flex-col gap-4 sm:flex-row"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <JanmaButton variant="primary" size="lg">
                Meet Sakhi
              </JanmaButton>
              <JanmaButton variant="secondary" size="lg">
                For Clinics
              </JanmaButton>
            </motion.div>
          </motion.div>

          {/* Right side - Line Morph Animation Placeholder */}
          <motion.div 
            className="relative flex items-center justify-center"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative w-full max-w-md aspect-square">
              {/* Soft radial glow background - brand/primary at 12% opacity */}
              <div 
                className="absolute inset-0 rounded-full blur-3xl"
                style={{
                  background: `radial-gradient(circle, rgba(44, 82, 130, 0.12) 0%, rgba(44, 82, 130, 0.04) 50%, transparent 70%)`
                }}
              ></div>
              
              {/* Line morph animation placeholder */}
              <svg 
                viewBox="0 0 400 400" 
                className="w-full h-full relative z-10"
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
              >
                <motion.path
                  d="M50 200 Q200 50 350 200 Q200 350 50 200"
                  stroke="currentColor"
                  strokeWidth="3"
                  fill="none"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: 1 }}
                  transition={{ duration: 2, ease: "easeInOut", delay: 1 }}
                  className="text-primary"
                />
                
                {/* Couple representation */}
                <motion.circle
                  cx="100"
                  cy="150"
                  r="15"
                  fill="currentColor"
                  className="text-primary/70"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5, delay: 1.5 }}
                />
                <motion.circle
                  cx="130"
                  cy="150"
                  r="15"
                  fill="currentColor"
                  className="text-primary/70"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5, delay: 1.7 }}
                />
                
                {/* Pregnancy representation */}
                <motion.ellipse
                  cx="200"
                  cy="180"
                  rx="25"
                  ry="35"
                  fill="currentColor"
                  className="text-primary/50"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5, delay: 2 }}
                />
                
                {/* Cradle representation */}
                <motion.rect
                  x="285"
                  y="170"
                  width="40"
                  height="25"
                  rx="5"
                  fill="currentColor"
                  className="text-primary/60"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5, delay: 2.3 }}
                />
                
                {/* Connecting glow dots */}
                <motion.circle
                  cx="160"
                  cy="165"
                  r="3"
                  fill="currentColor"
                  className="text-accent"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 1, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 2.5 }}
                />
                <motion.circle
                  cx="240"
                  cy="175"
                  r="3"
                  fill="currentColor"
                  className="text-accent"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 1, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 2.7 }}
                />
              </svg>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}