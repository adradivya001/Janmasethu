import { motion } from "motion/react";
import { useState } from "react";
import { Sprout, Heart, Microscope, Baby, Smile } from "lucide-react";

const journeyStages = [
  {
    icon: Sprout,
    title: "Thinking of Parenthood",
    oneLiner: "Prep for the journey.",
    tooltip: "Sakhi guides you at this stage."
  },
  {
    icon: Heart,
    title: "Trying Naturally",
    oneLiner: "Track and optimize.",
    tooltip: "Sakhi guides you at this stage."
  },
  {
    icon: Microscope,
    title: "Exploring Options",
    oneLiner: "Navigate treatments.",
    tooltip: "Sakhi guides you at this stage."
  },
  {
    icon: Baby,
    title: "Pregnancy",
    oneLiner: "Evidence-based care.",
    tooltip: "Sakhi guides you at this stage."
  },
  {
    icon: Smile,
    title: "Post-Delivery",
    oneLiner: "Recovery support.",
    tooltip: "Sakhi guides you at this stage."
  }
];

export function JourneySection() {
  const [hoveredStage, setHoveredStage] = useState<number | null>(null);

  return (
    <section className="py-16 md:py-20 lg:py-24 px-4 bg-gradient-to-r from-muted/20 to-accent/10">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Sprout className="text-green-500" size={24} />
            <h2 className="text-3xl md:text-4xl">Parenthood Journey</h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive support at every stage of your parenthood journey
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Connection line */}
          <div className="absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-primary/30 via-primary to-primary/30 rounded-full transform -translate-y-1/2 hidden md:block">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
              initial={{ width: 0 }}
              whileInView={{ width: "100%" }}
              transition={{ duration: 2, ease: "easeInOut" }}
              viewport={{ once: true }}
            />
          </div>

          {/* Stages */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8 md:gap-4">
            {journeyStages.map((stage, index) => (
              <motion.div
                key={stage.title}
                className="relative text-center group cursor-pointer"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                onMouseEnter={() => setHoveredStage(index)}
                onMouseLeave={() => setHoveredStage(null)}
                whileHover={{ scale: 1.05 }}
              >
                {/* Stage icon - 48x48 holder */}
                <div className="relative mx-auto w-12 h-12 mb-4">
                  <div className="absolute inset-0 bg-background rounded-full border-2 border-primary group-hover:border-accent transition-colors duration-300 shadow-lg"></div>
                  <div className="absolute inset-1 bg-primary group-hover:bg-accent rounded-full flex items-center justify-center transition-colors duration-300">
                    <stage.icon className="text-background" size={20} />
                  </div>
                  
                  {/* Glow effect */}
                  <motion.div
                    className="absolute inset-0 bg-primary/20 rounded-full blur-md"
                    animate={{ 
                      scale: hoveredStage === index ? 1.5 : 1,
                      opacity: hoveredStage === index ? 0.6 : 0.3
                    }}
                    transition={{ duration: 0.3 }}
                  />
                </div>

                {/* Stage content - one liner */}
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">{stage.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {stage.oneLiner}
                  </p>
                </div>

                {/* Tooltip */}
                <motion.div
                  className="absolute top-full left-1/2 transform -translate-x-1/2 mt-4 p-3 bg-card border border-border rounded-lg shadow-lg z-10 w-64 text-sm"
                  initial={{ opacity: 0, y: 10, scale: 0.9 }}
                  animate={{ 
                    opacity: hoveredStage === index ? 1 : 0,
                    y: hoveredStage === index ? 0 : 10,
                    scale: hoveredStage === index ? 1 : 0.9
                  }}
                  transition={{ duration: 0.2 }}
                  style={{ pointerEvents: hoveredStage === index ? 'auto' : 'none' }}
                >
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-card border-l border-t border-border rotate-45"></div>
                  <p className="text-muted-foreground">{stage.tooltip}</p>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <motion.button
            className="inline-flex items-center gap-2 px-8 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            See how Sakhi supports you →
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}