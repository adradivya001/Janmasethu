import { motion } from "motion/react";
import { useState } from "react";
import { Award, Shield, Users, CheckCircle } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const clinicianReviews = [
  {
    name: "Dr. Sarah Chen",
    title: "Reproductive Endocrinologist",
    credentials: "MD, FACOG - 15 years experience",
    hospital: "Metro Fertility Center",
    rating: 5,
    review: "JanmaSethu has significantly improved our patient preparation rates. The evidence-based guidance helps patients arrive more informed and ready."
  },
  {
    name: "Dr. Rajesh Kumar",
    title: "IVF Specialist", 
    credentials: "MD, DGO - 12 years experience",
    hospital: "Advanced Fertility Clinic",
    rating: 5,
    review: "The comprehensive approach to patient education has reduced our consultation time while improving outcomes. Highly recommended."
  },
  {
    name: "Dr. Emily Rodriguez",
    title: "Maternal-Fetal Medicine",
    credentials: "MD, MFM - 18 years experience", 
    hospital: "Women's Health Institute",
    rating: 5,
    review: "Sakhi provides accurate, culturally sensitive guidance that complements our clinical care beautifully."
  }
];

const ngoCitations = [
  {
    name: "WHO Guidelines",
    description: "Aligned with World Health Organization reproductive health standards"
  },
  {
    name: "ACOG Recommendations", 
    description: "Following American College of Obstetricians and Gynecologists protocols"
  },
  {
    name: "ESHRE Standards",
    description: "Compliant with European Society of Human Reproduction guidelines"
  }
];

export function EvidenceSection() {
  const [hoveredReview, setHoveredReview] = useState<number | null>(null);

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Shield className="text-green-500" size={24} />
            <h2 className="text-3xl md:text-4xl">Evidence & Credibility</h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Trusted by healthcare professionals and backed by leading medical organizations
          </p>
        </motion.div>

        {/* Clinician Reviews */}
        <div className="mb-16">
          <motion.h3 
            className="text-2xl text-center mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Clinician Reviews
          </motion.h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {clinicianReviews.map((review, index) => (
              <motion.div
                key={review.name}
                className="group relative cursor-pointer"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                onMouseEnter={() => setHoveredReview(index)}
                onMouseLeave={() => setHoveredReview(null)}
                whileHover={{ y: -5 }}
              >
                <div className="relative p-6 bg-card border border-border rounded-2xl shadow-lg group-hover:shadow-xl transition-all duration-300">
                  {/* Review stamp */}
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center">
                      <Award className="text-green-500" size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{review.name}</h4>
                      <p className="text-sm text-muted-foreground">{review.title}</p>
                    </div>
                    <div className="flex gap-1">
                      {[...Array(review.rating)].map((_, i) => (
                        <div key={i} className="w-4 h-4 bg-yellow-400 rounded-full"></div>
                      ))}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground leading-relaxed">
                    "{review.review}"
                  </p>

                  {/* Credentials overlay */}
                  <motion.div
                    className="absolute inset-0 bg-card/95 backdrop-blur-sm rounded-2xl p-6 flex flex-col justify-center"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: hoveredReview === index ? 1 : 0 }}
                    transition={{ duration: 0.3 }}
                    style={{ pointerEvents: hoveredReview === index ? 'auto' : 'none' }}
                  >
                    <div className="text-center space-y-3">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                        <Users className="text-primary" size={24} />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">{review.name}</h4>
                        <p className="text-sm text-muted-foreground mb-2">{review.credentials}</p>
                        <p className="text-sm text-primary">{review.hospital}</p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* NGO Citations */}
        <div className="mb-16">
          <motion.h3 
            className="text-2xl text-center mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Medical Guidelines Compliance
          </motion.h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {ngoCitations.map((citation, index) => (
              <motion.div
                key={citation.name}
                className="text-center p-6 bg-card border border-border rounded-2xl"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-12 h-12 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="text-blue-500" size={24} />
                </div>
                <h4 className="font-medium mb-2">{citation.name}</h4>
                <p className="text-sm text-muted-foreground">{citation.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Disclaimer */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="bg-muted/50 border border-border rounded-2xl p-8 max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Shield className="text-primary" size={24} />
              <h3 className="text-xl">Our Commitment</h3>
            </div>
            <div className="grid md:grid-cols-3 gap-6 text-sm text-muted-foreground">
              <div className="space-y-2">
                <div className="text-primary font-medium">Ethical Curation</div>
                <div>All content reviewed by medical professionals and updated based on latest research.</div>
              </div>
              <div className="space-y-2">
                <div className="text-primary font-medium">Privacy by Design</div>
                <div>HIPAA-compliant platform with end-to-end encryption and data minimization.</div>
              </div>
              <div className="space-y-2">
                <div className="text-primary font-medium">Guidance, Not Diagnosis</div>
                <div>Educational support that complements, never replaces, professional medical care.</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}