import { motion } from "motion/react";
import { Users, Building2, TrendingUp } from "lucide-react";

const aboutCards = [
  {
    icon: Users,
    title: "Patients",
    oneLiner: "Guidance, not diagnosis.",
    color: "text-blue-500"
  },
  {
    icon: Building2,
    title: "Clinics",
    oneLiner: "Prep-ready patients, fewer cancellations.",
    color: "text-green-500"
  },
  {
    icon: TrendingUp,
    title: "Investors",
    oneLiner: "Scalable, ethical, defensible.",
    color: "text-purple-500"
  }
];

export function AboutSection() {
  return (
    <section className="py-16 md:py-20 lg:py-24 px-4 bg-gradient-to-b from-background to-muted/10">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">About JanmaSethu</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We bridge the gap between medical expertise and personal guidance, serving patients, clinics, and investors.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {aboutCards.map((card, index) => (
            <motion.div
              key={card.title}
              className="group relative"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -4 }}
            >
              {/* Glassmorphic card with enhanced effects */}
              <div className="relative p-8 rounded-2xl backdrop-blur-[12px] bg-white/10 border border-border/30 shadow-md group-hover:shadow-md group-hover:border-accent/50 transition-all duration-300">
                
                <div className="relative z-10">
                  <div className={`inline-flex p-3 rounded-xl bg-background/30 backdrop-blur-sm mb-6 ${card.color}`}>
                    <card.icon size={28} />
                  </div>
                  
                  <h3 className="text-xl mb-4">{card.title}</h3>
                  <p className="text-muted-foreground leading-relaxed text-[16px]">
                    {card.oneLiner}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}