
  # JanmaSethu Landing Page Design

  This is a code bundle for JanmaSethu Landing Page Design. The original project is available at https://www.figma.com/design/gm8cECD4EGp7xaYFxomVQf/JanmaSethu-Landing-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  